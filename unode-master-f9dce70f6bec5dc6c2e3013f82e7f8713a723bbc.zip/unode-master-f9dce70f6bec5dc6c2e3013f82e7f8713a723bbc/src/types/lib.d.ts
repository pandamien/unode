declare interface Object {
  [key: string]: any;
}
